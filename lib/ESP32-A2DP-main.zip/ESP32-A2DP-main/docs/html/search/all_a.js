var searchData=
[
  ['me_0',['Sponsor Me',['../index.html#autotoc_md22',1,'']]],
  ['metadata_1',['Support for Metadata',['../index.html#autotoc_md9',1,'']]],
  ['mono_5fdownmix_2',['mono_downmix',['../class_a2_d_p_volume_control.html#a8b449f76c7c931cf590732a3d73acaea',1,'A2DPVolumeControl']]],
  ['music_20receiver_3',['A2DP Sink (Music Receiver)',['../index.html#autotoc_md3',1,'']]],
  ['music_20receiver_20and_20sender_20for_20the_20esp32_4',['A Simple Arduino Bluetooth Music Receiver and Sender for the ESP32',['../index.html',1,'']]],
  ['music_20sender_5',['A2DP Source (Music Sender)',['../index.html#autotoc_md12',1,'']]]
];
