var searchData=
[
  ['with_20a_20callback_0',['Sending Data from a A2DS Data Source with a Callback',['../index.html#autotoc_md13',1,'']]],
  ['with_20callbacks_1',['Accessing the Sink Data Stream with Callbacks',['../index.html#autotoc_md8',1,'']]],
  ['write_5faudio_2',['write_audio',['../class_bluetooth_a2_d_p_sink.html#aa211fefd101a639938a20dc3478b48ae',1,'BluetoothA2DPSink::write_audio()'],['../class_bluetooth_a2_d_p_sink_queued.html#a1846088388d294f04469885b9bb560e4',1,'BluetoothA2DPSinkQueued::write_audio()']]]
];
