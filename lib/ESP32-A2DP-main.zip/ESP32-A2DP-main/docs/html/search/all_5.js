var searchData=
[
  ['fast_5fforward_0',['fast_forward',['../class_bluetooth_a2_d_p_sink.html#a42e01689353026b1ef9883fd5d32f00c',1,'BluetoothA2DPSink']]],
  ['for_20avrc_20commands_1',['Support for AVRC Commands',['../index.html#autotoc_md11',1,'']]],
  ['for_20metadata_2',['Support for Metadata',['../index.html#autotoc_md9',1,'']]],
  ['for_20notifications_3',['Support for Notifications',['../index.html#autotoc_md10',1,'']]],
  ['for_20the_20esp32_4',['A Simple Arduino Bluetooth Music Receiver and Sender for the ESP32',['../index.html',1,'']]],
  ['from_20a_20a2ds_20data_20source_20with_20a_20callback_5',['Sending Data from a A2DS Data Source with a Callback',['../index.html#autotoc_md13',1,'']]]
];
