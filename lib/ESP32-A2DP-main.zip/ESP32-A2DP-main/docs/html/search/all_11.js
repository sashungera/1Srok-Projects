var searchData=
[
  ['update_5faudio_5fdata_0',['update_audio_data',['../class_a2_d_p_volume_control.html#a8f23bd37f10a58fd03cebe5d9b180802',1,'A2DPVolumeControl::update_audio_data(uint8_t *data, uint16_t byteCount)'],['../class_a2_d_p_volume_control.html#a6eb1add5a68fe554c6705cb9fad25545',1,'A2DPVolumeControl::update_audio_data(Frame *data, uint16_t frameCount)'],['../class_a2_d_p_no_volume_control.html#ab7e6d29791af0c5820679170838bc241',1,'A2DPNoVolumeControl::update_audio_data()']]],
  ['update_5frssi_1',['update_rssi',['../class_bluetooth_a2_d_p_sink.html#a3b43ee67031c300d07638f9c969fa4ef',1,'BluetoothA2DPSink']]],
  ['using_20default_20pins_2',['A Simple I2S Example (A2DS Sink) using default Pins',['../index.html#autotoc_md4',1,'']]],
  ['using_20the_20esp32_20i2s_20api_3',['Output Using the ESP32 I2S API',['../index.html#autotoc_md6',1,'']]]
];
